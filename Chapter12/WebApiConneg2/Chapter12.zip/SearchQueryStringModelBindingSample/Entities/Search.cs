﻿namespace SearchQueryStringModelBindingSample.Entities {
    public class Search {
        public string Text { get; set; }
        public int MaxResults { get; set; }
    }
}